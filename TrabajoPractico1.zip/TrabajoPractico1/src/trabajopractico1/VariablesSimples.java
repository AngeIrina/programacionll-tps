/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajopractico1;

/**
 *
 * @author Angela Ramos
 */

// Consigna 3 - TP1
public class VariablesSimples {

    public static void main(String[] args) {
        String nombre = "Angela";
        int edad = 25;
        double altura = 1.61;
        boolean estudiante = true;
        
        // System.out.println("Mi nombre es " + nombre + ", tengo " + edad + " años, mido " + altura + " metros.");
        System.out.println("Tengo " + edad + " años.");
        System.out.println("Mi altura es " + altura + " metros.");
        System.out.println( nombre + " ¿Sos estudiante? " + estudiante + ".");
                
    }
    
}
