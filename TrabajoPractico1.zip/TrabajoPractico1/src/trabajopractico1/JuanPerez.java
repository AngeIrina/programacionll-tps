/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajopractico1;

public class JuanPerez {

    public static void main(String[] args) {
        String nombre = "Juan Pérez";
        String direccion = "Calle falsa 123";
        int edad = 30;
        
        System.out.println("Nombre: " + nombre + "\nEdad: " + edad + " años\nDirección: \"" + direccion + "\"");
    }
    
}
